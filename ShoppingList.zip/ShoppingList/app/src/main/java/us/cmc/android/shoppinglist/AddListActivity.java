package us.cmc.android.shoppinglist;

/**
 * Created by alexclemens on 11/12/16.
 */
import android.content.Intent;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import java.util.ArrayList;
import java.util.List;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import butterknife.BindView;
import butterknife.OnClick;
import us.cmc.android.shoppinglist.adapter.CustomOnItemSelectedListener;
import us.cmc.android.shoppinglist.adapter.TodoRecyclerAdapter;
import us.cmc.android.shoppinglist.data.Todo;

public class AddListActivity extends AppCompatActivity {

    public static final String KEY_TODO = "KEY_TODO";
    private Spinner spinner1;
    private Button btnSubmit;
    private TodoRecyclerAdapter todoRecyclerAdapter;
    private RecyclerView recyclerTodo;

    @BindView(R.id.activity_add_todo)
    LinearLayout layoutTodos;

    private Todo todoToEdit = null;

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_add_todo);
        final EditText etTodo = (EditText) findViewById(R.id.etTodo);
        final EditText etPrice = (EditText) findViewById(R.id.etPrice);
        final EditText etDesc = (EditText) findViewById(R.id.etDescription);
        final Spinner sType = (Spinner) findViewById(R.id.spinner1);
        final CheckBox done = (CheckBox) findViewById(R.id.checkbox);


        //addListenerOnButton();
        addListenerOnSpinnerItemSelection();

        if (getIntent() != null
                && getIntent().hasExtra(MainActivity.KEY_TODO_TO_EDIT)) {
            todoToEdit = (Todo) getIntent().getSerializableExtra(MainActivity.KEY_TODO_TO_EDIT);
            etTodo.setText(todoToEdit.getTodoTitle());
        }

        Button btnSave = (Button) findViewById(R.id.btnAddItem);
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent result = new Intent();

                Todo newTodo = todoToEdit;
                if (newTodo == null) {
                    newTodo = new Todo(etTodo.getText().toString(),
                            0.0,
                            etDesc.getText().toString(),
                            sType.getSelectedItem().toString(),
                            done.isChecked());
                } else {
                    newTodo.setTodoTitle(etTodo.getText().toString());
                    newTodo.setTodoDescription(etDesc.getText().toString());
                    newTodo.setTodoItemType(spinner1.getSelectedItem().toString());
                    newTodo.setDone(done.isChecked());

                }
                if(etPrice.getText().length()>0){
                    newTodo.setTodoPrice(Double.parseDouble(etPrice.getText().toString()));
                }
                else{
                    newTodo.setTodoPrice(0.0);
                }


                result.putExtra(KEY_TODO, newTodo);

                setResult(RESULT_OK, result);
                finish();
            }
        });

    }
/*    private void setupAddTodo() {
        final EditText etTodo = (EditText) findViewById(R.id.etTodo);
        final EditText etPrice = (EditText) findViewById(R.id.etPrice);
        final EditText etDesc = (EditText) findViewById(R.id.etDescription);
        final Spinner sType = (Spinner) findViewById(R.id.spinner1);

        Button btnAdd = (Button) findViewById(R.id.btnAddItem);
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                todoRecyclerAdapter.addTodo(
                        new Todo(etTodo.getText().toString(),
                                Double.parseDouble(etPrice.toString()),
                                etDesc.getText().toString(),
                                sType.toString(),
                                false));
                recyclerTodo.scrollToPosition(0);
            }
        });
    }*/


    public void addListenerOnSpinnerItemSelection() {
        spinner1 = (Spinner) findViewById(R.id.spinner1);
        spinner1.setOnItemSelectedListener(new CustomOnItemSelectedListener());
    }


}
