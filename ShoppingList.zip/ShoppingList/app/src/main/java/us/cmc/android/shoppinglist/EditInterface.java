package us.cmc.android.shoppinglist;

import us.cmc.android.shoppinglist.data.Todo;

/**
 * Created by alexclemens on 11/12/16.
 */
public interface EditInterface {
    public void showEditDialog(Todo todoToEdit, int position);
}
