package us.cmc.android.shoppinglist;

import android.content.ClipData;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import us.cmc.android.shoppinglist.adapter.TodoItemTouchHelperCallback;
import us.cmc.android.shoppinglist.adapter.TodoRecyclerAdapter;
import us.cmc.android.shoppinglist.data.Todo;

public class MainActivity extends AppCompatActivity implements EditInterface {

    public static final int REQUEST_CODE_ADD = 100;
    public static final String KEY_TODO_TO_EDIT = "KEY_TODO_TO_EDIT";
    public static final int REQUEST_CODE_EDIT = 101;
    private TodoRecyclerAdapter todoRecyclerAdapter;
    private RecyclerView recyclerTodo;
    private int positionToEdit = -1;
    private Long idToEdit = null;
    @BindView(R.id.content_main)
    LinearLayout layoutTodos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ButterKnife.bind(this);

        setupUI();
    }

    private void setupUI() {
        setupToolbar();
        //setupFloatingActionButton();
        setupRecyclerView();
        //setupAddTodo();
    }

    private void setupRecyclerView() {
        recyclerTodo = (RecyclerView) findViewById(
                R.id.recyclerTodo);
        recyclerTodo.setHasFixedSize(true);
        final LinearLayoutManager mLayoutManager =
                new LinearLayoutManager(this);
        recyclerTodo.setLayoutManager(mLayoutManager);


        todoRecyclerAdapter = new TodoRecyclerAdapter(this);



        ItemTouchHelper.Callback callback = new TodoItemTouchHelperCallback(todoRecyclerAdapter);
        ItemTouchHelper touchHelper = new ItemTouchHelper(callback);
        touchHelper.attachToRecyclerView(recyclerTodo);

        recyclerTodo.setAdapter(todoRecyclerAdapter);
    }

    /*private void setupFloatingActionButton() {
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.btnAddTodo);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentShowAdd = new Intent();
                intentShowAdd.setClass(MainActivity.this, AddTodoActivity.class);
                startActivityForResult(intentShowAdd, REQUEST_CODE_ADD);
            }
        });
    }*/

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_CODE_ADD) {
                // add todo to the list
                Todo newTodo = (Todo) data.getSerializableExtra(
                        AddListActivity.KEY_TODO);

                todoRecyclerAdapter.addTodo(newTodo);
                recyclerTodo.scrollToPosition(0);
            } else if (requestCode == REQUEST_CODE_EDIT) {

                Todo changedTodo = (Todo) data.getSerializableExtra(
                        AddListActivity.KEY_TODO);
                changedTodo.setId(idToEdit);

                todoRecyclerAdapter.edit(changedTodo, positionToEdit);

            }
        }
    }

    private void setupToolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);

    }



    @Override
    public void showEditDialog(Todo todoToEdit, int position) {
        positionToEdit = position;
        idToEdit = todoToEdit.getId();
        Intent intentShowEdit = new Intent();
        intentShowEdit.setClass(MainActivity.this, AddListActivity.class);
        intentShowEdit.putExtra(KEY_TODO_TO_EDIT,todoToEdit);
        startActivityForResult(intentShowEdit, REQUEST_CODE_EDIT);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.createNewItem) {

            Intent intentShowAdd = new Intent();
            intentShowAdd.setClass(MainActivity.this, AddListActivity.class);
            startActivityForResult(intentShowAdd, REQUEST_CODE_ADD);


            return true;
        }else if(id == R.id.deleteAllItems){

            todoRecyclerAdapter.deleteAll();

            return true;
        }


        return super.onOptionsItemSelected(item);
    }
}