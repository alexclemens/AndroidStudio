package us.cmc.android.shoppinglist.adapter;

/**
 * Created by alexclemens on 11/12/16.
 */
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

import us.cmc.android.shoppinglist.EditInterface;
import us.cmc.android.shoppinglist.R;
import us.cmc.android.shoppinglist.data.Todo;

public class TodoRecyclerAdapter extends
        RecyclerView.Adapter<TodoRecyclerAdapter.ViewHolder>
        implements TodoTouchHelperAdapter {

    private List<Todo> todoList;
    private EditInterface editInterface;

    public TodoRecyclerAdapter(EditInterface editInterface) {
        this.editInterface = editInterface;

        todoList = Todo.listAll(Todo.class);

        /*todoList = new ArrayList<Todo>();
        for (int i = 0; i < 20; i++) {
            todoList.add(new Todo("Todo"+i,false));
        }*/

    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View todoRow = LayoutInflater.from(parent.getContext()).inflate(
                R.layout.todo_row,parent,false);
        return new ViewHolder(todoRow);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
        holder.tvPrice.setText(todoList.get(position).getTodoPrice()+" ");
        holder.tvTodo.setText(todoList.get(position).getTodoTitle());
        holder.tvDescription.setText(todoList.get(position).getTodoDescription());
        holder.done.setChecked(todoList.get(position).isDone());
        holder.tvType.setText(todoList.get(position).getItemType());

        if(todoList.get(position).getItemType().equals("Book")){
        holder.imgView.setImageResource(R.drawable.book);}
        else if(todoList.get(position).getItemType().equals("Electronic")){
            holder.imgView.setImageResource(R.drawable.electronic);}
        else if(todoList.get(position).getItemType().equals("No Type")){
            holder.imgView.setImageResource(R.drawable.unknown);}
        else if(todoList.get(position).getItemType().equals("Food")){
            holder.imgView.setImageResource(R.drawable.food);}


        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                todoList.get(holder.getAdapterPosition()).delete();
                todoList.remove(holder.getAdapterPosition());
                notifyItemRemoved(holder.getAdapterPosition());
            }
        });
        holder.done.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                todoList.get(holder.getAdapterPosition()).setDone(holder.done.isChecked());
                todoList.get(holder.getAdapterPosition()).save();
                notifyDataSetChanged();


            }
        });

        holder.details.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editInterface.showEditDialog(
                        todoList.get(holder.getAdapterPosition()), holder.getAdapterPosition());
            }
        });
    }

    @Override
    public int getItemCount() {
        return todoList.size();
    }

    @Override
    public void onItemDismiss(int position) {
        todoList.get(position).delete();

        todoList.remove(position);
        notifyItemRemoved(position);
    }

    @Override
    public void onItemMove(int fromPosition, int toPosition) {
        /*if (fromPosition < toPosition) {
            for (int i = fromPosition; i < toPosition; i++) {
                Collections.swap(todoList, i, i + 1);
            }
        } else {
            for (int i = fromPosition; i > toPosition; i--) {
                Collections.swap(todoList, i, i - 1);
            }
        }*/

        //Collections.

        todoList.add(toPosition, todoList.get(fromPosition));
        todoList.remove(fromPosition);


        notifyItemMoved(fromPosition, toPosition);
    }

    public void deleteAll() {
        Todo.deleteAll(Todo.class);
        todoList = Todo.listAll(Todo.class);
        notifyDataSetChanged();
    }

    public void deleteSingle() {

    }

    public static class ViewHolder extends RecyclerView.ViewHolder{

        private TextView tvPrice;
        private TextView tvTodo;
        private TextView tvDescription;
        private TextView tvType;
        private Button delete;
        private Button details;
        private CheckBox done;
        private ImageView imgView;


        public ViewHolder(View itemView) {
            super(itemView);
            tvPrice = (TextView) itemView.findViewById(R.id.tvPrice);
            tvTodo = (TextView) itemView.findViewById(R.id.tvTodo);
            tvDescription = (TextView) itemView.findViewById(R.id.tvDescription);
            tvType = (TextView) itemView.findViewById(R.id.tvItemType);
            done = (CheckBox) itemView.findViewById(R.id.done);
            delete = (Button) itemView.findViewById(R.id.deleteSingle);
            details = (Button) itemView.findViewById(R.id.viewDetails);
            imgView = (ImageView) itemView.findViewById(R.id.imgCategory);

        }
    }

    public void addTodo(Todo todo) {
        todo.save();
        todoList.add(0, todo);

        // refresh the whole list
        //notifyDataSetChanged();
        // refresh only one position
        notifyItemInserted(0);
    }

    public void edit(Todo todo, int position) {

        todo.save();
        todoList.set(position, todo);
        notifyItemChanged(position);
    }
}