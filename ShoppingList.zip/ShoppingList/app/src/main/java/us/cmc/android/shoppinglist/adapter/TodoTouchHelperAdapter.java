package us.cmc.android.shoppinglist.adapter;

/**
 * Created by alexclemens on 11/12/16.
 */
public interface TodoTouchHelperAdapter {

    void onItemDismiss(int position);

    void onItemMove(int fromPosition, int toPosition);

}
