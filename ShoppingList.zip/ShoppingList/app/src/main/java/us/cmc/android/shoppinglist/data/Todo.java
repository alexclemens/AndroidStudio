package us.cmc.android.shoppinglist.data;

import com.orm.SugarRecord;

import java.io.Serializable;

public class Todo extends SugarRecord implements Serializable{

    private String todoTitle;
    private double todoPrice;
    private String todoDescription;
    private String todoItemType;
    private boolean done;

    public Todo(){

    }

    public Todo(String todoTitle, double todoPrice, String todoDescription,String todoItemType, boolean done) {
        this.todoTitle = todoTitle;
        this.todoPrice = todoPrice;
        this.todoDescription = todoDescription;
        this.todoItemType = todoItemType;
        this.done = done;
    }

    public String getTodoTitle() {
        return todoTitle;
    }

    public void setTodoTitle(String todoTitle) {
        this.todoTitle = todoTitle;
    }

    public double getTodoPrice(){return todoPrice;}

    public void setTodoPrice(double todoPrice) {
        this.todoPrice = todoPrice;
    }

    public String getTodoDescription() {
        return todoDescription;
    }

    public void setTodoDescription(String todoDescription) {
        this.todoDescription = todoDescription;
    }

    public String getItemType(){return todoItemType;}

    public void setTodoItemType(String todoItemType){this.todoItemType = todoItemType;}

    public boolean isDone() {
        return done;
    }

    public void setDone(boolean done) {
        this.done = done;
    }
}
