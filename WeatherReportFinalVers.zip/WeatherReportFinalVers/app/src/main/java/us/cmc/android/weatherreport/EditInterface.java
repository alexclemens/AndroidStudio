package us.cmc.android.weatherreport;

import us.cmc.android.weatherreport.model.SList;

/**
 * Created by alexclemens on 11/30/16.
 */
public interface EditInterface {
    public void showEditDialog(SList todoToEdit, int position);
}
