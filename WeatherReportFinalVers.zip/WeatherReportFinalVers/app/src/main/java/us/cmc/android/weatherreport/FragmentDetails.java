package us.cmc.android.weatherreport;

/**
 * Created by alexclemens on 11/27/16.
 */
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

public class FragmentDetails extends Fragment {

    public static final String TAG = "FragmentDetails";

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_details, null);
        try {

            TextView tvLow = (TextView) root.findViewById(R.id.tvLowTemp);
            TextView tvHigh = (TextView) root.findViewById(R.id.tvHighTemp);
            TextView tvWind = (TextView) root.findViewById(R.id.tvWind);

            tvLow.setText(getString(R.string.low) + ((WeatherActivity) getActivity()).getWeatherData().getMain().getTempMin());
            tvHigh.setText(getString(R.string.high) + ((WeatherActivity) getActivity()).getWeatherData().getMain().getTempMax());
            tvWind.setText(getString(R.string.windSpeed) + ((WeatherActivity) getActivity()).getWeatherData().getWind().getSpeed());
        }
        catch(NullPointerException e){
            TextView tvLow = (TextView) root.findViewById(R.id.tvTemperature);
            tvLow.setText(R.string.errorMsg);
        }


        return root;
    }
}
