package us.cmc.android.weatherreport;

/**
 * Created by alexclemens on 11/27/16.
 */
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import us.cmc.android.weatherreport.data.Example;


public class FragmentMain extends Fragment {

    public static final String TAG = "FragmentMain";

    private TextView tvTemp;
    private TextView tvLocation;
    private TextView tvDescription;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_main, null);

        ImageView imageView = (ImageView) root.findViewById(R.id.tvIcon);
        try {

            String iconID = ((WeatherActivity) getActivity()).getWeatherData().getWeather().get(0).getIcon();
            Glide.with(this).load((getString(R.string.weatherUrl)) + iconID + getString(R.string.png)).into(imageView);


            tvTemp = (TextView) root.findViewById(R.id.tvTemperature);
            tvDescription = (TextView) root.findViewById(R.id.tvDescription);
            tvLocation = (TextView) root.findViewById(R.id.tvLocation);


            tvTemp.setText(getString(R.string.currTemp) + ((WeatherActivity) getActivity()).getWeatherData().getMain().getTemp());
            tvDescription.setText(getString(R.string.desc) + ((WeatherActivity) getActivity()).getWeatherData().getWeather().get(0).getDescription());
            tvLocation.setText(getString(R.string.location) + ((WeatherActivity) getActivity()).getWeatherData().getName());
        }
        catch(NullPointerException e){
            tvTemp = (TextView) root.findViewById(R.id.tvTemperature);
            tvTemp.setText(R.string.errorMsg);
        }


        return root;
    }


}
