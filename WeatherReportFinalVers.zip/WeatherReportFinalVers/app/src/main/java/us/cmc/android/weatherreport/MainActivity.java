package us.cmc.android.weatherreport;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.Toast;

import us.cmc.android.weatherreport.adapter.WeatherRecyclerAdapter;
import us.cmc.android.weatherreport.model.SList;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener, OnMessageFragmentAnswer, MessageFragment.OptionsFragmentInterface{


    public static final String KEY_MSG = "KEY_MSG";
    public static String userInput;
    private WeatherRecyclerAdapter weatherRecyclerAdapter;
    private RecyclerView recyclerCity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        FloatingActionButton btnDialog1 = (FloatingActionButton) findViewById(R.id.fab);
        btnDialog1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MessageFragment messageFragment = new MessageFragment();
                messageFragment.setCancelable(false);

                Bundle bundle = new Bundle();
                //bundle.putString(KEY_MSG, "you pressed button one");
                messageFragment.setArguments(bundle);

                messageFragment.show(getSupportFragmentManager(),
                        getString(R.string.msgFrag));
            }
        });


        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        setupRecyclerView();


    }
    private void setupRecyclerView() {
        recyclerCity = (RecyclerView) findViewById(
                R.id.recyclerList);
        recyclerCity.setHasFixedSize(true);
        final LinearLayoutManager mLayoutManager =
                new LinearLayoutManager(this);
        recyclerCity.setLayoutManager(mLayoutManager);


        weatherRecyclerAdapter = new WeatherRecyclerAdapter(this);

        recyclerCity.setAdapter(weatherRecyclerAdapter);
    }

    public void showWeatherActivity(String passIn) {
            Intent myIntent = new Intent(MainActivity.this, WeatherActivity.class);

            myIntent.putExtra(getString(R.string.cityNm), passIn);

            MainActivity.this.startActivity(myIntent);
    }



    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_about) {
            Toast.makeText(MainActivity.this, R.string.ThisIsMyApp, Toast.LENGTH_LONG).show();

        } else if (id == R.id.nav_addcity) {
            MessageFragment messageFragment = new MessageFragment();
            messageFragment.setCancelable(false);

            Bundle bundle = new Bundle();
            messageFragment.setArguments(bundle);

            messageFragment.show(getSupportFragmentManager(),
                    getString(R.string.messageFragment));
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onPositiveSelected() {
        //Toast.makeText(this, userInput, Toast.LENGTH_SHORT).show();

        SList cityVal = new SList(userInput);
        weatherRecyclerAdapter.addTodo(cityVal);
        recyclerCity.scrollToPosition(0);
    }

    @Override
    public void onNegativeSelected() {
        Toast.makeText(this, R.string.Cancelled, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void getStringFromUser(String s) {
        userInput = s;
    }

    @Override
    public void onOptionsFragmentResult(String city) {
        Toast.makeText(this, getString(R.string.selectCity)+city, Toast.LENGTH_SHORT).show();
    }
}
