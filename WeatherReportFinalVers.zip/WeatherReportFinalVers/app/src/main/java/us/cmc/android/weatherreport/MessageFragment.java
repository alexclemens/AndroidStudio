package us.cmc.android.weatherreport;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AlertDialog;
import android.widget.EditText;
import android.widget.LinearLayout;

/**
 * Created by alexclemens on 11/30/16.
 */
public class MessageFragment extends DialogFragment implements DialogInterface.OnClickListener {

    private OnMessageFragmentAnswer onMessageFragmentAnswer = null;
    public static final String TAG = "OptionsFragment";


    public interface OptionsFragmentInterface {
        public void onOptionsFragmentResult(String fruit);
    }

    //private String[] options = {"Budapest, London, New York, Tokyo, Los Angeles, Honolulu, Paris, Shanghai, Vancouver"};
    private OptionsFragmentInterface optionsFragmentInterface;


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        try {
            if(context instanceof OnMessageFragmentAnswer ){
                onMessageFragmentAnswer = (OnMessageFragmentAnswer) context;
            }
            //optionsFragmentInterface =
              //      (OptionsFragmentInterface) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString()
                    + " must implement OptionsFragmentInterface");
        }
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        String message = getArguments().getString(MainActivity.KEY_MSG);

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                getActivity());

        //here we can add many other things to our dialog box
        alertDialogBuilder.setTitle("Enter a new city");

        //the message from the main activity
        alertDialogBuilder.setMessage(message);

        final EditText etInput = new EditText(getActivity());

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT);
        etInput.setLayoutParams(lp);
        alertDialogBuilder.setView(etInput);

        //alertDialogBuilder.setItems(options, this);

        alertDialogBuilder.setPositiveButton("Enter", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
                onMessageFragmentAnswer.getStringFromUser(etInput.getText().toString());
                onMessageFragmentAnswer.onPositiveSelected();

            }
        });

        alertDialogBuilder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                onMessageFragmentAnswer.onNegativeSelected();
            }

        });

        return alertDialogBuilder.create();
    }

    @Override
    public void onClick(DialogInterface dialog,
                        int choice) {
        //optionsFragmentInterface.onOptionsFragmentResult(
        //        options[choice]);
    }
}