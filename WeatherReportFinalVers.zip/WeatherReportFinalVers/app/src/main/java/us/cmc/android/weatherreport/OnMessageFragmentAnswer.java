package us.cmc.android.weatherreport;

/**
 * Created by alexclemens on 11/30/16.
 */
public interface OnMessageFragmentAnswer {

    public void onPositiveSelected();
    public void onNegativeSelected();
    public void getStringFromUser(String s);
}
