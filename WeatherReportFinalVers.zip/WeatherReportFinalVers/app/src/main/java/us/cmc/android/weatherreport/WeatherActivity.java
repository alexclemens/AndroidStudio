package us.cmc.android.weatherreport;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import us.cmc.android.weatherreport.api.WeatherApi;
import us.cmc.android.weatherreport.data.Example;

/**
 * Created by alexclemens on 11/27/16.
 */
public class WeatherActivity extends AppCompatActivity {

    private final String id = "f3d694bc3e1d44c1ed5a97bd1120e8fe";
    private String cityName;

    private Example weatherData = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.weather_activity);

        //get Value from main activity
        Bundle b = getIntent().getExtras();
        if(b != null) {
            cityName = b.getString(getString(R.string.cityName));
        }


        Button btnOne = (Button) findViewById(R.id.btnOne);
        btnOne.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showFragmentByTag(FragmentMain.TAG);
            }
        });
        Button btnTwo = (Button) findViewById(R.id.btnTwo);
        btnTwo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showFragmentByTag(FragmentDetails.TAG);
            }
        });
        Button btnClose = (Button) findViewById(R.id.btnClose);
        btnClose.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent mainIntent = new Intent(WeatherActivity.this,MainActivity.class);
                WeatherActivity.this.startActivity(mainIntent);
                WeatherActivity.this.finish();
            }
        });




            Retrofit retrofit = new Retrofit.Builder().baseUrl(
                    getString(R.string.apiLink)).
                    addConverterFactory(GsonConverterFactory.create()).build();
            final WeatherApi weatherApi = retrofit.create(WeatherApi.class);


            Call<Example> call = weatherApi.getWeather(cityName, getString(R.string.metric), id);
            call.enqueue(new Callback<Example>() {
                @Override
                public void onResponse(Call<Example> call, Response<Example> response) {
                    weatherData = response.body();
                    showFragmentByTag(FragmentMain.TAG);
                }

                @Override
                public void onFailure(Call<Example> call, Throwable t) {
                    Toast.makeText(WeatherActivity.this, t.getMessage(), Toast.LENGTH_LONG).show();
                }
            });


    }



    private void showFragmentByTag(String tag) {
        Fragment fragment =
                getSupportFragmentManager().findFragmentByTag(tag);

        if (fragment == null) {
            if (tag.equals(FragmentMain.TAG)) {
                fragment = new FragmentMain();

            } else if (tag.equals(FragmentDetails.TAG)){
                fragment = new FragmentDetails();
            }
        }

        FragmentTransaction transaction =
                getSupportFragmentManager().beginTransaction();

        transaction.setCustomAnimations(android.R.anim.slide_in_left, android.R.anim.slide_out_right);

        //use replace not add so fragments dont stack on top of each other
        transaction.replace(R.id.layoutContainer, fragment, tag);
        transaction.addToBackStack(null);

        transaction.commit();
    }

    public Example getWeatherData() {
        return weatherData;
    }
}
