package us.cmc.android.weatherreport.adapter;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import java.util.List;

import us.cmc.android.weatherreport.MainActivity;
import us.cmc.android.weatherreport.R;
import us.cmc.android.weatherreport.model.SList;

public class WeatherRecyclerAdapter extends
        RecyclerView.Adapter<WeatherRecyclerAdapter.ViewHolder> implements WeatherTouchHelperAdapter{

    private List<SList> stringList;
    private Context context;

    public WeatherRecyclerAdapter(Context context) {
        this.context = context;

        stringList = SList.listAll(SList.class);

        /*todoList = new ArrayList<Todo>();
        for (int i = 0; i < 20; i++) {
            todoList.add(new Todo("Todo"+i,false));
        }*/

    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View todoRow = LayoutInflater.from(parent.getContext()).inflate(
                R.layout.city_row,parent,false);
        return new ViewHolder(todoRow);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {

        holder.tvCity.setText(stringList.get(position).getCity());

/*        if(stringList.get(position).getCity().equals("Book")){
            holder.imgView.setImageResource(R.drawable.book);}
        else if(stringList.get(position).getItemType().equals("Electronic")){
            holder.imgView.setImageResource(R.drawable.electronic);}
        else if(stringList.get(position).getItemType().equals("No Type")){
            holder.imgView.setImageResource(R.drawable.unknown);}
        else if(stringList.get(position).getItemType().equals("Food")){
            holder.imgView.setImageResource(R.drawable.food);}*/


        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stringList.get(holder.getAdapterPosition()).delete();
                stringList.remove(holder.getAdapterPosition());
                notifyItemRemoved(holder.getAdapterPosition());
            }
        });
        holder.tvCity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String passIn = stringList.get(position).getCity();
                ((MainActivity)context).showWeatherActivity(passIn);
            }
        });

    }

    @Override
    public int getItemCount() {
        return stringList.size();
    }

    @Override
    public void onItemDismiss(int position) {
        stringList.get(position).delete();

        stringList.remove(position);
        notifyItemRemoved(position);
    }

    @Override
    public void onItemMove(int fromPosition, int toPosition) {


        stringList.add(toPosition, stringList.get(fromPosition));
        stringList.remove(fromPosition);


        notifyItemMoved(fromPosition, toPosition);
    }

    public void deleteAll() {
        SList.deleteAll(SList.class);
        stringList = SList.listAll(SList.class);
        notifyDataSetChanged();
    }



    public static class ViewHolder extends RecyclerView.ViewHolder{

        private TextView tvCity;
        private Button delete;


        public ViewHolder(View itemView) {
            super(itemView);
            tvCity = (TextView) itemView.findViewById(R.id.tvCityName);
            delete = (Button) itemView.findViewById(R.id.deleteSingle);

        }
    }

    public void addTodo(SList todo) {
        todo.save();
        stringList.add(0, todo);

        // refresh the whole list
        //notifyDataSetChanged();
        // refresh only one position
        notifyItemInserted(0);
    }

    public void edit(SList list, int position) {

        list.save();
        stringList.set(position, list);
        notifyItemChanged(position);
    }
}
