package us.cmc.android.weatherreport.adapter;

/**
 * Created by alexclemens on 12/1/16.
 */
public interface WeatherTouchHelperAdapter {
    void onItemDismiss(int position);

    void onItemMove(int fromPosition, int toPosition);
}
