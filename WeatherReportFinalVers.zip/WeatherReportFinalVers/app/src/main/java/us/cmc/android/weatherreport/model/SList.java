package us.cmc.android.weatherreport.model;

import com.orm.SugarRecord;

import java.io.Serializable;

/**
 * Created by alexclemens on 11/30/16.
 */
public class SList extends SugarRecord implements Serializable {
    private String city;

    public SList(){}

    public SList(String city){
        this.city = city;
    }

    public String getCity(){
        return city;
    }

    public void setCity(String city){
        this.city = city;
    }
}
